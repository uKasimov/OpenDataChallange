<div class="admin-default-index">
    <div class="row">
        <div class="col-md-4">
            <img src="http://192.168.137.107:8080/video" alt="">
        </div>
    </div>
</div>
